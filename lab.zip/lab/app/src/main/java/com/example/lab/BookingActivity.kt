package com.example.lab

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat

class BookingActivity : AppCompatActivity() {
    private val CHANNEL_ID = "hotel_booking_channel"
    private val NOTIFICATION_REQUEST_CODE = 1001
    private val NOTIFICATION_ID = 101

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_booking)

        val hotel = intent.getStringExtra("hotel")
        val location = intent.getStringExtra("location")
        val tvDetails = findViewById<TextView>(R.id.tvHotelDetails)
        val datePicker = findViewById<DatePicker>(R.id.datePicker)
        val btnBook = findViewById<Button>(R.id.btnBook)

        tvDetails.text = "Booking: $hotel in $location"

        createNotificationChannel()

        btnBook.setOnClickListener {
            // Check for notification permission before proceeding
            if (checkNotificationPermission()) {
                val date = "${datePicker.dayOfMonth}/${datePicker.month + 1}/${datePicker.year}"
                val intent = Intent(this, ConfirmationActivity::class.java)
                intent.putExtra("hotel", hotel)
                intent.putExtra("location", location)
                intent.putExtra("date", date)
                startActivity(intent)

                Log.d("BookingActivity", "Sending notification for $hotel on $date")
                sendNotification("Booking Confirmed", "Hotel $hotel booked for $date.")
            } else {
                // Request permission if not granted
                requestNotificationPermission()
                Toast.makeText(this, "Please grant notification permission to receive booking confirmations", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun checkNotificationPermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(
                this,
                android.Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
        } else {
            // For versions before Android 13 (TIRAMISU), notification permission was granted by default
            true
        }
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(android.Manifest.permission.POST_NOTIFICATIONS),
                    NOTIFICATION_REQUEST_CODE
                )
            }
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)

        if (requestCode == NOTIFICATION_REQUEST_CODE) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Notification permission granted", Toast.LENGTH_SHORT).show()
                // User may press the button again to complete the booking
            } else {
                Toast.makeText(this, "Notification permission denied. Some features may not work properly.", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun sendNotification(title: String, content: String) {
        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title)
            .setContentText(content)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)

        val notifMgr = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        notifMgr.notify(NOTIFICATION_ID, builder.build())
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Bookings",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Channel for booking confirmations"
            }

            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(channel)
        }
    }
}
package com.example.lab

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class ConfirmationActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_confirmation)

        val hotel = intent.getStringExtra("hotel")
        val location = intent.getStringExtra("location")
        val date = intent.getStringExtra("date")

        val tv = findViewById<TextView>(R.id.tvConfirmation)
        tv.text = "Your booking at $hotel in $location on $date is confirmed!"
    }
}
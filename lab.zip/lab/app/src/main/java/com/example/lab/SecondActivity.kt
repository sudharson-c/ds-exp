package com.example.lab

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class SecondActivity : AppCompatActivity() {
    lateinit var sharedPref: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        sharedPref = getSharedPreferences("user_pref", MODE_PRIVATE)

        // Auto-login if already logged in
        if (sharedPref.getBoolean("loggedIn", false)) {
            startActivity(Intent(this, MainActivity::class.java))
            finish()
        }

        setContentView(R.layout.activity_second)

        val etUser = findViewById<EditText>(R.id.etUsername)
        val etPass = findViewById<EditText>(R.id.etPassword)
        val btnLogin = findViewById<Button>(R.id.btnLogin)
        val progress = findViewById<ProgressBar>(R.id.progressBar)

        btnLogin.setOnClickListener {
            progress.visibility = View.VISIBLE
            btnLogin.isEnabled = false

            // Simulate login
            it.postDelayed({
                if (etUser.text.toString() == "admin" && etPass.text.toString() == "admin") {
                    sharedPref.edit().putBoolean("loggedIn", true).apply()
                    startActivity(Intent(this, MainActivity::class.java))
                    finish()
                } else {
                    Toast.makeText(this, "Login Failed", Toast.LENGTH_SHORT).show()
                }
                progress.visibility = View.GONE
                btnLogin.isEnabled = true
            }, 1500)
        }
    }
}
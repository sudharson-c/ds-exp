package com.example.lab

import android.Manifest
import android.annotation.SuppressLint
import android.app.*
import android.app.AlertDialog
import android.content.*
import android.content.pm.PackageManager
import android.location.*
import android.os.*
import android.view.*
import android.widget.*
import androidx.appcompat.app.*
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.google.android.gms.location.*
import java.util.*

class MainActivity : AppCompatActivity() {

    lateinit var listView: ListView
    lateinit var locationText: TextView
    lateinit var spinner: Spinner
    lateinit var popupButton: Button

    val hotels = listOf("Hotel Taj", "Grand Hyatt", "The Leela", "Oberoi", "Radisson Blu")
    val locations = listOf("New York", "London", "Mumbai", "Chennai", "Paris")

    val CHANNEL_ID = "hotel_channel"
    val LOCATION_PERMISSION_REQUEST_CODE = 101
    lateinit var fusedLocationClient: FusedLocationProviderClient

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val toolbar = findViewById<androidx.appcompat.widget.Toolbar>(R.id.myToolbar)
        setSupportActionBar(toolbar)

        locationText = findViewById(R.id.tvLocation)
        spinner = findViewById(R.id.spinnerLocation)
        listView = findViewById(R.id.listHotels)
        popupButton = findViewById(R.id.btnPopup)

        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, locations)
        listView.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, hotels)
        registerForContextMenu(listView)

        popupButton.setOnClickListener {
            val popup = PopupMenu(this, popupButton)
            popup.menuInflater.inflate(R.menu.popup_menu, popup.menu)
            popup.setOnMenuItemClickListener {
                Toast.makeText(this, "${it.title} clicked", Toast.LENGTH_SHORT).show()
                true
            }
            popup.show()
        }

        listView.setOnItemClickListener { _, _, pos, _ ->
            val hotel = hotels[pos]
            showBookingDialog(hotel)
        }

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)
        requestLocationPermission()

        createNotificationChannel()
    }

    private fun requestLocationPermission() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),
                LOCATION_PERMISSION_REQUEST_CODE)
        } else {
            getCurrentLocation()
        }
    }

    @SuppressLint("MissingPermission")
    private fun getCurrentLocation() {
        fusedLocationClient.lastLocation.addOnSuccessListener { location: Location? ->
            location?.let {
                val geocoder = Geocoder(this, Locale.getDefault())
                val addresses = geocoder.getFromLocation(it.latitude, it.longitude, 1)
                val address = addresses?.firstOrNull()
                address?.let { addr ->
                    locationText.text = "You are in ${addr.locality}, ${addr.countryName}"
                } ?: run {
                    locationText.text = "Location not found"
                }
            } ?: run {
                locationText.text = "Unable to get location"
            }
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == LOCATION_PERMISSION_REQUEST_CODE && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            getCurrentLocation()
        } else {
            locationText.text = "Permission Denied"
        }
    }

    private fun showBookingDialog(hotel: String) {
        val calendar = Calendar.getInstance()

        // Step 1: Date Picker
        val datePicker = DatePickerDialog(this, { _, year, month, dayOfMonth ->
            calendar.set(Calendar.YEAR, year)
            calendar.set(Calendar.MONTH, month)
            calendar.set(Calendar.DAY_OF_MONTH, dayOfMonth)

            // Step 2: Time Picker
            val timePicker = TimePickerDialog(this, { _, hourOfDay, minute ->
                calendar.set(Calendar.HOUR_OF_DAY, hourOfDay)
                calendar.set(Calendar.MINUTE, minute)

                val dateTime = android.text.format.DateFormat.format("dd MMM yyyy, hh:mm a", calendar)
                AlertDialog.Builder(this)
                    .setTitle("Confirm Booking")
                    .setMessage("Do you want to book $hotel on $dateTime?")
                    .setPositiveButton("Yes") { _, _ ->
                        Toast.makeText(this, "$hotel booked on $dateTime!", Toast.LENGTH_SHORT).show()
                        sendNotification("$hotel on $dateTime")
                    }
                    .setNegativeButton("No", null)
                    .show()

            }, calendar.get(Calendar.HOUR_OF_DAY), calendar.get(Calendar.MINUTE), false)

            timePicker.show()

        }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH))

        datePicker.show()
    }

    private fun sendNotification(content: String) {
        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle("Booking Confirmed")
            .setContentText("Your booking at $content is confirmed.")
            .setPriority(NotificationCompat.PRIORITY_HIGH)

        with(NotificationManagerCompat.from(this)) {
            notify(1, builder.build())
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val name = "Booking Channel"
            val desc = "Channel for booking confirmations"
            val importance = NotificationManager.IMPORTANCE_HIGH
            val channel = NotificationChannel(CHANNEL_ID, name, importance).apply {
                description = desc
            }
            val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.home_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.logout -> {
                getSharedPreferences("user_pref", MODE_PRIVATE).edit().clear().apply()
                startActivity(Intent(this, SecondActivity::class.java))
                finish()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    override fun onCreateContextMenu(menu: ContextMenu?, v: View?, menuInfo: ContextMenu.ContextMenuInfo?) {
        super.onCreateContextMenu(menu, v, menuInfo)
        menuInflater.inflate(R.menu.context_menu, menu)
    }

    override fun onContextItemSelected(item: MenuItem): Boolean {
        val info = item.menuInfo as AdapterView.AdapterContextMenuInfo
        val hotel = hotels[info.position]

        return when (item.itemId) {
            R.id.context_view -> {
                Toast.makeText(this, "Viewing $hotel", Toast.LENGTH_SHORT).show()
                true
            }
            R.id.context_bookmark -> {
                Toast.makeText(this, "$hotel bookmarked", Toast.LENGTH_SHORT).show()
                true
            }
            else -> super.onContextItemSelected(item)
        }
    }
}

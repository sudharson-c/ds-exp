package com.example.hotel

import android.app.AlertDialog
import android.content.Context
import android.content.SharedPreferences
import android.location.Geocoder
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.*
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.*

class MainActivity : AppCompatActivity() {

    private lateinit var bookingStatus: TextView
    private lateinit var roomButton: Button
    private lateinit var progressBar: ProgressBar
    private lateinit var sharedPref: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        bookingStatus = findViewById(R.id.bookingStatus)
        roomButton = findViewById(R.id.roomButton)
        progressBar = findViewById(R.id.progressBar)

        registerForContextMenu(bookingStatus)

        // SharedPreferences
        sharedPref = getSharedPreferences("HotelPrefs", Context.MODE_PRIVATE)
        val editor = sharedPref.edit()
        editor.putString("username", "Pratika")
        editor.apply()
        val name = sharedPref.getString("username", "Guest")
        Toast.makeText(this, getString(R.string.welcome_user, name), Toast.LENGTH_SHORT).show()

        // Popup Menu
        roomButton.setOnClickListener {
            val popup = PopupMenu(this, it)
            popup.menuInflater.inflate(R.menu.popup_menu, popup.menu)
            popup.setOnMenuItemClickListener { item ->
                when (item.itemId) {
                    R.id.view_details -> showAddress()
                    R.id.book_now -> confirmBooking()
                }
                true
            }
            popup.show()
        }

        // Progress Bar Simulation
        progressBar.visibility = View.VISIBLE
        Handler(Looper.getMainLooper()).postDelayed({
            progressBar.visibility = View.GONE
            bookingStatus.text = getString(R.string.room_available)
        }, 3000)
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.options_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        Toast.makeText(this, getString(R.string.selected_option, item.title), Toast.LENGTH_SHORT).show()
        return true
    }

    override fun onCreateContextMenu(
        menu: ContextMenu?,
        v: View?,
        menuInfo: ContextMenu.ContextMenuInfo?
    ) {
        super.onCreateContextMenu(menu, v, menuInfo)
        menuInflater.inflate(R.menu.context_menu, menu)
    }

    override fun onContextItemSelected(item: MenuItem): Boolean {
        Toast.makeText(this, getString(R.string.context_action, item.title), Toast.LENGTH_SHORT).show()
        return true
    }

    private fun showAddress() {
        lifecycleScope.launch {
            val addressList = withContext(Dispatchers.IO) {
                val geocoder = Geocoder(this@MainActivity, Locale.getDefault())
                geocoder.getFromLocation(13.0827, 80.2707, 1)
            }
            if (!addressList.isNullOrEmpty()) {
                val address = addressList[0].getAddressLine(0)
                bookingStatus.text = getString(R.string.hotel_location, address)
            }
        }
    }

    private fun confirmBooking() {
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.confirm_title))
            .setMessage(getString(R.string.confirm_message))
            .setPositiveButton(getString(R.string.yes)) { _, _ ->
                Toast.makeText(this, getString(R.string.booking_success), Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton(getString(R.string.no), null)
            .show()
    }
}
